package com.example.inventariopr.model

data class Producto(

    val nombre: String,
    val codigo: String,
    val categoria: String,
    val precioCompra: Double,
    val precioVenta: Double,
    val stock: Int,
    val stockMinimo: Int

) {

    fun estadoStock(): String {

        return if (stock > 0) {
            "En Stock"
        } else {
            "Sin Stock"
        }
    }
}
