package com.example.inventariopr.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.inventariopr.model.Producto

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProductScreen(
    productos: MutableList<Producto>
) {

    var nombre by remember { mutableStateOf("") }
    var codigo by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf("") }
    var precioCompra by remember { mutableStateOf("") }
    var precioVenta by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var stockMinimo by remember { mutableStateOf("") }

    val categorias = listOf(
        "Electrónicos",
        "Electrodomésticos",
        "TV",
        "Computadoras",
        "Audio"
    )

    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),

        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        Text(
            text = "Agregar Producto"
        )

        OutlinedTextField(
            value = nombre,
            onValueChange = {
                nombre = it
            },
            label = {
                Text("Nombre del Producto")
            },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = codigo,
            onValueChange = {
                codigo = it
            },
            label = {
                Text("Código")
            },
            modifier = Modifier.fillMaxWidth()
        )

        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = {
                expanded = !expanded
            }
        ) {

            OutlinedTextField(
                value = categoria,
                onValueChange = {},
                readOnly = true,
                label = {
                    Text("Categoría")
                },
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded)
                },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
            )

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = {
                    expanded = false
                }
            ) {

                categorias.forEach { item ->

                    DropdownMenuItem(
                        text = {
                            Text(item)
                        },
                        onClick = {
                            categoria = item
                            expanded = false
                        }
                    )
                }
            }
        }

        OutlinedTextField(
            value = precioCompra,
            onValueChange = {
                precioCompra = it
            },
            label = {
                Text("Precio de Compra")
            },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = precioVenta,
            onValueChange = {
                precioVenta = it
            },
            label = {
                Text("Precio de Venta")
            },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = stock,
            onValueChange = {
                stock = it
            },
            label = {
                Text("Stock Inicial")
            },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = stockMinimo,
            onValueChange = {
                stockMinimo = it
            },
            label = {
                Text("Stock Mínimo")
            },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {

                if (
                    nombre.isNotEmpty() &&
                    codigo.isNotEmpty() &&
                    categoria.isNotEmpty() &&
                    precioCompra.isNotEmpty() &&
                    precioVenta.isNotEmpty() &&
                    stock.isNotEmpty() &&
                    stockMinimo.isNotEmpty()
                ) {

                    productos.add(
                        Producto(
                            nombre = nombre,
                            codigo = codigo,
                            categoria = categoria,
                            precioCompra = precioCompra.toDouble(),
                            precioVenta = precioVenta.toDouble(),
                            stock = stock.toInt(),
                            stockMinimo = stockMinimo.toInt()
                        )
                    )

                    nombre = ""
                    codigo = ""
                    categoria = ""
                    precioCompra = ""
                    precioVenta = ""
                    stock = ""
                    stockMinimo = ""
                }
            },

            modifier = Modifier.fillMaxWidth()
        ) {

            Text("Guardar Producto")
        }
    }
}