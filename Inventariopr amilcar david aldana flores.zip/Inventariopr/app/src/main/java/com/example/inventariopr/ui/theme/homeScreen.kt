package com.example.inventariopr.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.inventariopr.model.Producto

@Composable
fun HomeScreen(
    productos: List<Producto>,
    navController: NavController
) {

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),

        contentPadding = PaddingValues(10.dp),

        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        itemsIndexed(productos) { index, producto ->

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        navController.navigate("detail/$index")
                    },

                elevation = CardDefaults.cardElevation(
                    defaultElevation = 5.dp
                )
            ) {

                Column(
                    modifier = Modifier.padding(16.dp)
                ) {

                    Text(
                        text = producto.nombre,
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text(
                        text = "Código: ${producto.codigo}"
                    )

                    Text(
                        text = "Categoría: ${producto.categoria}"
                    )

                    Text(
                        text = "Stock Disponible: ${producto.stock}"
                    )

                    Text(
                        text = "Estado: ${producto.estadoStock()}"
                    )

                    if (producto.stock <= producto.stockMinimo) {

                        Text(
                            text = "⚠ Stock Bajo"
                        )
                    }
                }
            }
        }
    }
}