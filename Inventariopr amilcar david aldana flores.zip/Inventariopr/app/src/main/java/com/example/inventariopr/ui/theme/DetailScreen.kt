package com.example.inventariopr.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.inventariopr.model.Producto

@Composable
fun DetailScreen(
    producto: Producto
) {

    Card(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),

        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        )
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),

            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            Text(
                text = producto.nombre,
                style = MaterialTheme.typography.headlineMedium
            )

            Divider()

            Spacer(modifier = Modifier.height(5.dp))

            Text(
                text = "Código: ${producto.codigo}",
                style = MaterialTheme.typography.bodyLarge
            )

            Text(
                text = "Categoría: ${producto.categoria}",
                style = MaterialTheme.typography.bodyLarge
            )

            Text(
                text = "Precio de Compra: Q ${producto.precioCompra}",
                style = MaterialTheme.typography.bodyLarge
            )

            Text(
                text = "Precio de Venta: Q ${producto.precioVenta}",
                style = MaterialTheme.typography.bodyLarge
            )

            Text(
                text = "Unidades en Stock: ${producto.stock}",
                style = MaterialTheme.typography.bodyLarge
            )

            Text(
                text = "Stock Mínimo: ${producto.stockMinimo}",
                style = MaterialTheme.typography.bodyLarge
            )

            Text(
                text = "Estado: ${producto.estadoStock()}",
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (producto.stock <= producto.stockMinimo) {

                Text(
                    text = "⚠ Producto con stock bajo",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}