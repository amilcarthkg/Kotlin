package com.example.inventariopr.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.inventariopr.model.Producto
import com.example.inventariopr.ui.AddProductScreen
import com.example.inventariopr.ui.DetailScreen
import com.example.inventariopr.ui.HomeScreen
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding

@Composable
fun AppNavigation() {

    val navController = rememberNavController()

    val productos = remember {

        mutableStateListOf(

            Producto(
                nombre = "Smart TV Samsung",
                codigo = "TV001",
                categoria = "TV",
                precioCompra = 2500.0,
                precioVenta = 3200.0,
                stock = 10,
                stockMinimo = 2
            ),

            Producto(
                nombre = "Microondas",
                codigo = "EL001",
                categoria = "Electrodomésticos",
                precioCompra = 800.0,
                precioVenta = 1200.0,
                stock = 5,
                stockMinimo = 1
            )
        )
    }

    Scaffold(

        bottomBar = {

            NavigationBar {

                NavigationBarItem(
                    selected = false,

                    onClick = {
                        navController.navigate("home")
                    },

                    icon = {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Inicio"
                        )
                    },

                    label = {
                        Text("Inicio")
                    }
                )

                NavigationBarItem(
                    selected = false,

                    onClick = {
                        navController.navigate("add")
                    },

                    icon = {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Agregar"
                        )
                    },

                    label = {
                        Text("Agregar")
                    }
                )
            }
        }

    ) { paddingValues ->

        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(paddingValues)
        ) {

            composable("home") {

                HomeScreen(
                    productos = productos,
                    navController = navController
                )
            }

            composable("add") {

                AddProductScreen(
                    productos = productos
                )
            }

            composable("detail/{index}") { backStackEntry ->

                val index =
                    backStackEntry.arguments
                        ?.getString("index")
                        ?.toIntOrNull() ?: 0

                DetailScreen(
                    producto = productos[index]
                )
            }
        }
    }
}


